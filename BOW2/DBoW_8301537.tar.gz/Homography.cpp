

#include "Homography.h"
//Converts matching indices to xy points
    void matches2points(const vector<KeyPoint>& train, const vector<KeyPoint>& query,
        const std::vector<cv::DMatch>& matches, std::vector<cv::Point2f>& pts_train,
        std::vector<Point2f>& pts_query)
    {

        pts_train.clear();
        pts_query.clear();
        pts_train.reserve(matches.size());
        pts_query.reserve(matches.size());

        size_t i = 0;

        for (; i < matches.size(); i++)
        {

            const DMatch & dmatch = matches[i];

            pts_query.push_back(query[dmatch.queryIdx].pt);
            pts_train.push_back(train[dmatch.trainIdx].pt);

        }

    }
    //Takes a descriptor and turns it into an xy point
    void keypoints2points(const vector<KeyPoint>& in, vector<Point2f>& out)
    {
        out.clear();
        out.reserve(in.size());
        for (size_t i = 0; i < in.size(); ++i)
        {
            out.push_back(in[i].pt);
        }
    }

    //Takes an xy point and appends that to a keypoint structure
    void points2keypoints(const vector<Point2f>& in, vector<KeyPoint>& out)
    {
        out.clear();
        out.reserve(in.size());
        for (size_t i = 0; i < in.size(); ++i)
        {
            out.push_back(KeyPoint(in[i], 1));
        }
    }
        //Uses computed homography H to warp original input points to new planar position
    void warpKeypoints( const vector<KeyPoint>& in, vector<KeyPoint>& out,const Mat& H)
    {
        vector<Point2f> pts;
        keypoints2points(in, pts);
        vector<Point2f> pts_w(pts.size());
        Mat m_pts_w(pts_w);
        perspectiveTransform(Mat(pts), m_pts_w, H);
        points2keypoints(pts_w, out);
    }
// ----------------------------------------------------------------------------
int checkHomography( const stringstream &cap_src, QueryResults &ret,
		      uint &img_index)
{
  vector<vector<vector<float> > >  result;
  std::vector<KeyPoint> keypoints_object, res_keypoints;
  
//   Mat capImgDesp(features[0].size(),features[0][0].size(),CV_32F);
//   cout <<capImgDesp.rows << " " << capImgDesp.cols << endl;
//   for(uint i=0; i<features[0].size(); i++)
//   {
//     Mat temp(features[0][i]);
//     cv::transpose(temp,temp);  
//     capImgDesp.row(i)=temp.row(0);
//     //cout <<temp.rows << " " << temp.cols << endl;
//   }

  //-- Step 1: Extract keypoints and descriptors
  vector<cv::KeyPoint> cap_keypoints;
  Mat cap_Descriptors,  res_image;  
  

  
  //cap_src << "../snap-unknown-20120825-200118-1.jpeg"	;
  Mat cap_image = imread(cap_src.str(),CV_LOAD_IMAGE_GRAYSCALE);
  initModule_nonfree();

  Ptr<Feature2D> sift1 = Algorithm::create<Feature2D>("Feature2D.SIFT");
  sift1->set("contrastThreshold", 0.01f);
  (*sift1)(cap_image, noArray(), cap_keypoints, cap_Descriptors);
    
  
  for (uint cur_dbImage=1; cur_dbImage<ret.size(); cur_dbImage++) //get rid of the top 1 itself
  {
    //-- Step 2: Extract keypoitns and descriptors for each image of result set
    unsigned int id = ret[cur_dbImage].Id; 
    stringstream ret_src;
    ret_src << "../../New_modules/image_";
    if(id<10) 			ret_src<< "00"<<id<< ".jpeg";
    if(id>=10&&id<100) 		ret_src<< "0"<<id<< ".jpeg";
    if(id>=100	)		ret_src<< id << ".jpeg";
    cout << ret_src.str()<<endl;
     res_image = imread(ret_src.str(),CV_LOAD_IMAGE_GRAYSCALE);
//     vector<cv::KeyPoint> res_keypoints;
//     cv::Mat res_Descriptors;
//     
//      (*sift1)(res_image, noArray(), res_keypoints, res_Descriptors);
// 
//     //-- Step 3: Matching descriptor vectors using FLANN matcher
//     FlannBasedMatcher matcher;
     vector< DMatch > matches;
//     matcher.match( res_Descriptors, cap_Descriptors, matches);
//     
//     Mat img_matches;
//     drawMatches( res_image, res_keypoints, cap_image, cap_keypoints, 
//                matches, img_matches, Scalar::all(-1), Scalar::all(-1), 
//                vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS ); 
//     imshow("img_matches",img_matches);
//     //waitKey();
//     double max_dist = 0; double min_dist = 1000;
// 
//     //-- Step 4: Quick calculation of max and min distances between keypoints
//     for( int i = 0; i < res_Descriptors.rows; i++ )
//     { double dist = matches[i].distance;
//       if( dist < min_dist ) min_dist = dist;
//       if( dist > max_dist ) max_dist = dist;
//     }
//     
//     cout << "-- Max dist : " << max_dist <<endl;
//     cout << "-- Min dist : " << min_dist <<endl;
//     
//     //-- Step 5: Grab the good matches point set
//     std::vector<Point2f> pt_cap_frame;
//     std::vector<Point2f> pt_result;
//     do{
//       for( int i = 0; i < res_Descriptors.rows; i++ )
//       { 
// 	if( matches[i].distance < 3.5*min_dist )
// 	{ 
// 
// 	  pt_cap_frame.push_back( cap_keypoints[ matches[i].queryIdx ].pt );
// 	  pt_result.push_back( res_keypoints[ matches[i].trainIdx ].pt ); 
// 	}
//       }  
//       if(pt_cap_frame.size()<4) min_dist+=0.1; //Doing Homog has to get more than 4 pairs.
//     }while(pt_cap_frame.size()<4);
    
    
    //Mat H = findHomography( pt_cap_frame, pt_result, CV_RANSAC );
    

  vector<Point2f> train_pts, query_pts;
  vector<KeyPoint> train_kpts, query_kpts;
  vector<unsigned char> match_mask;
  Mat original_desc, query_desc;
   Mat train_desc;
   const int DESIRED_FTRS = 500;
//    GridAdaptedFeatureDetector detector1(new FastFeatureDetector(10, true), DESIRED_FTRS, 4, 4);
//    detector1.detect(cap_image, query_kpts); //Find interest points
//   BriefDescriptorExtractor brief(32);
//   brief.compute(cap_image, query_kpts, query_desc);
//   
   vector<Point2f> test_pts;
//   //warpKeypoints( query_kpts, test_kpts,H.inv());
//    detector1.detect(res_image, train_kpts); //Find interest points
//   brief.compute(res_image, train_kpts, train_desc);
//   
//   
//   BFMatcher desc_matcher(NORM_HAMMING);
//   //Mat mask = windowedMatchingMask(test_kpts, train_kpts, 25, 25);
//   desc_matcher.match(query_desc, train_desc, matches);
//   cout << matches.size();
  //drawKeypoints(frame, test_kpts, frame, Scalar(255, 0, 0), DrawMatchesFlags::DRAW_OVER_OUTIMG);

  matches2points(res_keypoints, cap_keypoints, matches, train_pts, query_pts);
  cout << matches.size() << endl;
  if (matches.size() > 300)
  {
      Mat H = findHomography(train_pts, query_pts, RANSAC, 4, match_mask);
      cout << countNonZero(Mat(match_mask));
      if (countNonZero(Mat(match_mask)) > 100)
      {
	  cout 	<< endl
		<< "*****************************" << endl
		<< "the result is : image" << id << endl
		<< "reranking from " << cur_dbImage <<endl
		<< "*****************************" << endl << endl;
		
		cout << match_mask.size() << " " << train_pts.size()<<" "<<query_pts.size()<<endl;
		for(int j=0;j<match_mask.size();j++)
		  cout <<(int)match_mask[j] << " ";
		  cout <<endl;
		
		perspectiveTransform( train_pts, test_pts, H);
		
  Mat cap_image1, res_image1;
  cap_image.copyTo(cap_image1);
  res_image.copyTo(res_image1);
  cvtColor(cap_image1,cap_image1,CV_GRAY2RGB);
  cvtColor(res_image1,res_image1,CV_GRAY2RGB);  
  for(uint i=0; i<train_kpts.size();i++)
  {
    circle( cap_image1, test_pts[i], 2, Scalar(0, 255, 0), CV_FILLED, CV_AA );
    circle( cap_image1, query_pts[i], 2, Scalar(0, 0, 255), CV_FILLED, CV_AA );
    circle( res_image1, train_kpts[i].pt, 2, Scalar(0, 0, 255), CV_FILLED, CV_AA );
    
  }

  
  imshow(cap_src.str(), cap_image1);
  stringstream out;
  out << "image_" << ret[cur_dbImage].Id;
  namedWindow(out.str());
  moveWindow(out.str(), 660, 200);
  imshow(out.str(), res_image1);
  waitKey(0);
  destroyAllWindows();
  
	  return ret[cur_dbImage].Id;
      }
      else
	  cout<< "Homography is not match"<<endl;
      //drawMatchesRelative(train_kpts, query_kpts, matches, frame, match_mask);
  }
  else
     cout<< "matches is too small. not match"<<endl;
    

  }
  return 0 ;
}